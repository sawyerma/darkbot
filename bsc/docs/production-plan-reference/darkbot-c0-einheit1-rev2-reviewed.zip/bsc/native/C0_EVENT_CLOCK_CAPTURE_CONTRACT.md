# C0 Minimalvertrag: Event, Clock, Attempt, 15-Sekunden-Capture

Status: **VORSCHLAG ZUM EINFRIEREN** (2026-10-03). Nichts hiervon ist implementiert.
Zweck: die Begriffe und Pflichtfelder festlegen, bevor der erste Verbraucher gebaut wird (Einheiten 4 bis 6, C1, Recorder).
Der Vertrag legt Semantik fest, noch kein Byte-Layout. Das Layout wird mit der ersten Implementierung in `darkbot-wire` versioniert eingefroren.

Übernommene Quellen, nicht neu definiert:
`docs/GATE0_TESTPLAN_SHORT.md:81–87` (Zeitgrenzen), Abschnitt „Current task amendment — 2026-10-03" B/C/D (Producer-Messung, 15-Sekunden-Capture),
`docs/BSC_NATIVE_SINGLE_RUNTIME_CONTRACT.md` §3 (Ingress-Events), §5 (Fast Lane), §7 (Journal), §12 (L0–L9).

## 1. Clock

Rusts `Instant` und Gos monotone Zeit sind prozessintern und nicht serialisierbar. Sie dürfen weder gespeichert noch gegeneinander verrechnet werden. Jeder gespeicherte Zeitpunkt ist ein `ClockStamp`.

```text
ClockStamp
  domain    ClockDomain   welche Uhr
  ticks_ns  u64           Nanosekunden in dieser Uhr
```

| `ClockDomain` | Bedeutung | Wer stempelt |
|---|---|---|
| `HOST_MONOTONIC` | monotone Betriebssystem-Uhr des DarkBot-Hosts, von jedem Prozess explizit über dieselbe Uhr-ID gelesen | geth-Hook, Rust-Runtime, Recorder |
| `PRODUCER_MONOTONIC` | monotone Uhr eines instrumentierten Blockproduzenten | nur dessen Instrumentierung |
| `CHAIN_HEADER_MS` | `milliTimestamp` aus dem Block-Header | Recorder, aus kanonischen Daten |
| `EVENT_SECONDS` | Sekundenwert aus einem Contract-Event | Recorder |
| `WALL_UTC` | Wanduhr, nur zur menschlichen Einordnung | Recorder |

Konstante Angaben stehen einmal je Session und Domain im Journal, nicht in jedem Stempel:

```text
ClockInfo
  domain
  boot_id            Host-Boot-Kennung (bei PRODUCER: Node-/Boot-ID des Produzenten)
  os_clock_id        z. B. CLOCK_MONOTONIC
  resolution_ns      gemeldete Auflösung
  read_overhead_ns   gemessene Kosten eines Lesezugriffs
  uncertainty_ns     Unsicherheit je Stempel (mindestens max(resolution, read_overhead))
  source             welcher Prozess/Hook diese Uhr liest
```

Regeln:

1. Eine Differenz ist nur zwischen zwei Stempeln derselben Domain **und** derselben `boot_id` definiert. Jede andere Differenz ist `UNKNOWN`.
2. `T0` und `T_buy` als Zahlen gibt es nur in `PRODUCER_MONOTONIC`, gebunden an denselben Ausführungsversuch des später kanonischen Blocks. Fehlt diese Quelle: `T0 → T_buy = UNKNOWN`.
3. `CHAIN_HEADER_MS`, `EVENT_SECONDS` und `WALL_UTC` liefern Reihenfolge und Einordnung, nie eine Ausführungszeit.
4. Hook-Aufwand vor dem Stempel wird gemessen und ausgewiesen; ein später Hook darf keine Zeit verstecken.
5. Kein RTT-Abzug, keine Umrechnung zwischen Domains ohne dokumentierte, gemessene Abbildung mit eigener Unsicherheit.

## 2. Identität

| Kennung | Bedeutung |
|---|---|
| `session_id` | eindeutig je Prozessstart der Runtime |
| `source_id` | ein Ingress-Adapter-Exemplar (Art, Version, Endpunkt/Region) |
| `seq` | lückenlose Sequenznummer je Quelle bzw. je Ring; eine fehlende Nummer ist eine Datenlücke |
| `attempt_id` | ein wirtschaftlicher Kaufversuch auf einen Launch; eindeutig je `session_id` |
| `intent_id` | genau eine signierte BUY-Identität innerhalb eines Attempts |

Bindung eines Intents (alle Felder Pflicht, vor dem ersten Write festgeschrieben):
`chain_id`, `sender`, `nonce`, `token`, `recipient`, `tx_hash` bzw. Bundle-Identität, `launch_tx_hash`.
Mehrere Inclusion-Adapter transportieren dieselbe `intent_id` mit denselben signierten Bytes. Ein neuer Nonce oder neue Bytes sind ein neuer Intent und nur nach kanonischem Abgleich zulässig.

## 3. Zeitgrenzen

Namen und Bedeutung unverändert aus Testplan und Runtime Contract. Alle lokalen Grenzen sind `HOST_MONOTONIC`.

| Grenze | Bedeutung | Entspricht |
|---|---|---|
| `T_signal` | Empfang des tatsächlich verwendeten actionable Signals | L0 am geth-Hook; L2 ist der Empfang in Rust |
| `decode` | Venue-Decode abgeschlossen | L3 |
| `decided` | Entscheidung und lokale Quote abgeschlossen | L4 |
| `built` | Transaktion/Bundle gebaut | L5 |
| `T_ready` | exakte BUY-TX/Bundle vollständig gebaut und signiert | L6 |
| `T_queue` | signierter Payload in lokale Adapter-/IPC-Queue geschrieben, falls vorhanden | — |
| `T_send` | signierter Payload an die tatsächlich getestete Transportgrenze übergeben (Write und Flush zurückgekehrt) | L7 |
| `ack` | Antwort des Adapters gelesen; **kein** Kauf, **kein** `confirm` | — |
| `T0` | erster Ausführungspunkt, an dem ein unabhängiger externer BUY gültig ausführbar ist | nur `PRODUCER_MONOTONIC` |
| `T_buy` | BUY erfolgreich ausgeführt, Erwerb belegt | nur `PRODUCER_MONOTONIC` |

`local_ready = T_ready − T_signal`, `local_send = T_send − T_signal`. `T_pre` gilt nur, wenn unabhängig belegt ist, dass das Signal vor externer Handelbarkeit lag.

## 4. Pflicht-Records

Jeder Record trägt `schema_version`, `session_id`, `seq` und mindestens einen `ClockStamp`.

**SessionHeader** — einmal je Start: Build-Kennung, Konfigurations-Hash, `chain_id`, alle `ClockInfo`, alle `source_id` mit Art und Version.

**RawTxSeen** — ein Ingress-Ereignis, unabhängig vom Envelope-Typ:

```text
source_id, seq, seen: ClockStamp
kind            EARLY_TX_SEEN | TXPOOL_ACCEPTED | HASH_ONLY | FEED_TARGET
tx_hash
envelope_type   0 | 1 | 2 | 3 | 4 | UNKNOWN
raw_signed      originale signierte Bytes (leer bei HASH_ONLY / FEED_TARGET)
sender, nonce, to, value, input   normalisierte gemeinsame Felder
fields_origin   wer die Felder geliefert hat (Hook | Rust-Decoder | Feed)
```

Die normalisierten Felder liefert der Adapter (beim gepinnten bsc-geth der Hook, der die Transaktion bereits dekodiert hat). Der Core hängt nicht vom Envelope-Typ ab. Der Recorder prüft abseits des Hotpaths, dass `tx_hash` und Felder zu `raw_signed` gehören; eine Abweichung ist ein eigener Fehler-Record. Nicht unterstützte oder unbekannte Typen werden gezählt (`UNSUPPORTED`, `UNKNOWN`), nicht still verworfen.

**HeadEvent** — kanonischer Kopf und Reorg: Blocknummer, Hash, Parent-Hash, Header-`milliTimestamp`, vollständige geordnete TX-Hash-Liste, bei Reorg alter und neuer Zweig.

**AttemptTransition** — jeder Zustandswechsel eines Attempts mit Stempel:

```text
attempt_id, intent_id (sobald vorhanden), at: ClockStamp
state   SIGNAL | DECODED | SKIPPED(reason) | DECIDED | BUILT | SIGNED | QUEUED
        | SENDING(adapter) | SENT(adapter) | ACK(adapter) | UNKNOWN_OUTCOME
        | INCLUDED(block, index) | REVERTED | CANONICAL | ORPHANED | LATE | EXPIRED
```

Übersprungene, verspätete und fehlgeschlagene Versuche werden genauso aufgezeichnet wie erfolgreiche.

**SubmissionIo** — je Adapter-Write: Adapter, Bytes-Hash des Requests, Ergebnis des Writes, ggf. ACK-Rohantwort ohne Credentials.

**Gap** — jede Lücke: betroffene Quelle bzw. Ring, erste fehlende `seq`, Anzahl, Stempel, Ursache (`OVERFLOW`, `DISCONNECT`, `SOURCE_ERROR`).

**CaptureWindow** — je Launch:

```text
launch_tx_hash, token, venue
armed_at: ClockStamp          vor dem Launch-Signal
window_basis                  PRODUCER_T0 | CANONICAL_BLOCK_SUPERSET
t0_exact                      true nur bei PRODUCER_T0
status                        OPEN | COMPLETE | INCOMPLETE(reason)
```

**ChainFact** — Rohdaten des Fensters, vom Recorder nachgeladen: Blöcke mit voller TX-Reihenfolge, Receipts und Logs (`TokenCreated`, `TokenBought`, `TokenSold`, Transfers), interne Router-/Portal-Aufrufe soweit belegbar, mit Angabe der Quelle und ob Traces verfügbar waren.

## 5. Hotpath-Regel

```text
                 ┌→ BUY-Hotpath → Inclusion-Adapter
natives Event ───┤
                 └→ begrenzter, vorallokierter Ring → Recorder → Journal
```

Der Hotpath schreibt Records nur in einen begrenzten, vorallokierten Ring und wartet nie. Ist der Ring voll, wird der Record verworfen und ein Zähler erhöht; der Recorder schreibt daraus einen `Gap`. Kein Dateizugriff, kein RPC, keine Datenbank, kein synchrones Logging vor `T_send`. Dekodierung, Nachladen von Receipts und Aggregation laufen im Recorder oder offline. Diese Trennung ist eine Modulgrenze, keine zusätzliche Task-, Prozess- oder Queue-Grenze im BUY-Pfad.

## 6. 15-Sekunden-Fenster

1. Capture ist **vor** dem Launch-Signal scharf (bounded Pre-Trigger-Puffer).
2. Mit Producer-`T0`: Fenster `[T0, T0 + 15 s]` in dessen Uhr, `t0_exact = true`.
3. Ohne Producer-`T0`: konservative Obermenge ab `armed_at` bis mindestens 15 s nach dem Header-Zeitpunkt des Launch-Blocks, einschließlich der Randblöcke; `window_basis = CANONICAL_BLOCK_SUPERSET`, `t0_exact = false`.
4. Der Abgleich läuft nach den 15 Sekunden weiter, bis Abdeckung und kanonischer Status feststehen. Reorgs erzeugen Revisionen, keine Überschreibung.
5. Lücken, Quellenausfall oder fehlende Abdeckung ergeben `INCOMPLETE`. Ein leeres Intervall ist kein Beleg für „keine Trades", wenn die Quelle ausgefallen war.
6. Preis, OHLCV, Rang und Kosten werden offline aus den Roh-Trades abgeleitet. Sie liefern keine Ausführungszeit.

## 7. Reihenfolge

**Vor dem ersten Verbraucher (jetzt einfrieren):** Abschnitte 1 bis 3 und die Record-Arten aus Abschnitt 4.

**Vor dem nächsten integrierten echten BUY (Minimal-Capture):**
`SessionHeader`, `RawTxSeen` für Launch und eigenen BUY, `AttemptTransition` mit allen lokalen Grenzen, `SubmissionIo`, `Gap`, `CaptureWindow`, sowie `ChainFact` für den Launch-Block und die folgenden 15 Sekunden.

**Später:** vollständiger Recorder (alle Venue-Events, Traces, Quellen-Health), Replay-Leser, Producer-Records.

## 8. Was dieser Vertrag nicht leistet

Ein Schema erzeugt keine Messung. `T0 → T_buy` bleibt `UNKNOWN`, bis ein instrumentierter Produzent Stempel in `PRODUCER_MONOTONIC` liefert, die an den kanonischen Block gebunden sind. Ein eigener Follower oder ein Replay misst die eigene Verarbeitung.
