# C0-Inventar: Gate-0-Code → Produktionsmodule

Revision 2, 2026-10-03. Grundlage: Repo-Archiv `darkbot-main (13)`, Verzeichnis `bsc/gates/gate0/src`.
Pflicht nach Arbeitsanweisung §25. Zeilenangaben beziehen sich auf diesen Stand.
Revision 2 arbeitet das Review vom 2026-10-03 ein (`FABLE_REVIEW.md` und der statische Zweit-Review).

## 1. Status Einheit 1 (RLP, Legacy-TX, Signer)

| Schritt (§23) | Stand |
|---|---|
| 1 Implementierungen identifiziert | erledigt (dieses Dokument) |
| 2 Zielmodul definiert | erledigt: `darkbot-wire::rlp`, `darkbot-core::tx::legacy`, `darkbot-core::signer` |
| 3 Code implementiert | erledigt: `bsc/native/` |
| 4 Tests geschrieben | 27 Tests: 8 RLP, 2 RLP-Differential, 7 Legacy-TX, 10 Signer |
| 5–7 Compiler, Tests, Lint | **Revision 1 vom Review ausgeführt** (Rust/Cargo 1.93.1): 23 Tests PASS, Clippy FAIL, Format FAIL. **Revision 2 ist nicht ausgeführt**: in der Erstellungsumgebung gibt es weder Rust-Toolchain noch Netz |
| 8 Review | Revision 1 geprüft; Revision 2 offen |
| 9 Commit / Import | offen, erst nach grünem Lauf von Revision 2 |

### Änderungen von Revision 1 zu Revision 2

| Review-Punkt | Änderung |
|---|---|
| Clippy `manual_is_multiple_of` (`rlp.rs`, `legacy.rs`) | beide Stellen auf `is_multiple_of(2)` |
| Format | Importe und überlange Zeilen von Hand an den 2024-Stil angeglichen. **Ohne `rustfmt` nicht prüfbar**: einmal `cargo fmt --all` ausführen; das ändert nur Layout |
| Reproduzierbarer Build | `rust-toolchain.toml` (1.93.1 mit rustfmt, clippy), `rust-version = "1.93"`, direkte Abhängigkeiten exakt: `alloy-primitives =1.7.3`, `k256 =0.13.4`. **`Cargo.lock` kann hier nicht erzeugt werden**; die im Review erzeugte Datei übernehmen bzw. mit `cargo generate-lockfile --offline` erzeugen und committen |
| Signatur-API | `LegacyTx::encode_signed` ist `pub(crate)`, `Signer::sign_prehash` privat. Einziger öffentlicher Weg zu signierten Bytes: `Signer::sign_legacy`. `RecoverableSignature` bleibt als ungeprüfte Wire-Darstellung des Decoders |
| Chain-Bindung | `recover_legacy_sender(signed, expected_chain_id, scratch)`; falsche Chain ergibt `SignerError::WrongChain`. Revision 1 hatte die Chain-Prüfung des Gate-0-`recover_sender` nicht übernommen |
| Puffer-Lifecycle | `sign_legacy` leert `out` zuerst und hinterlässt genau eine Transaktion, bei Fehler einen leeren Puffer. Neu: `max_signing_payload_len`, `max_signed_len` zum einmaligen Vorreservieren; Test über 1.024 Signaturen ohne Kapazitäts- oder Zeigeränderung |
| RLP auf fremden Bytes | `tests/rlp_differential.rs`: 27.624 strukturierte und zufällige Eingaben gegen `alloy-rlp` (Strings, Listen, Ganzzahlen, kein Panic), dazu Encoder-Vergleich. Kein Ersatz für Coverage-Fuzzing |
| `gas_price`-Typ | bleibt `u64`. `LegacyTx` ist ausdrücklich als DarkBots eigener ausgehender BSC-Aufruf dokumentiert, nicht als allgemeines Wire-Modell; ein breiterer Wert wird beim Dekodieren als Überlauf gemeldet (Test). Wechsel auf `U256` wäre lokal und offen, siehe E5 |

Ersatzprüfung ohne Compiler: Alle Algorithmen und alle neuen Tests sind zeilengleich in Python nachgebildet. Das Modell reproduziert den Mainnet-TX-Hash aus G0.3, das EIP-155-Beispiel und die 27.624 Differential-Fälle gegen eine Nachbildung des `alloy-rlp`-Algorithmus. Syntax- und Typfehler in den Rust-Änderungen von Revision 2 sind trotzdem möglich.

### Befehle für die Prüfumgebung

```bash
cd bsc/native
cargo generate-lockfile --offline          # nur falls noch kein Cargo.lock vorliegt
cargo fmt --all
cargo test --workspace --locked --offline
cargo test --workspace --release --locked --offline
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
cargo fmt --all -- --check
```

`alloy-rlp` ist nur Test-Abhängigkeit von `darkbot-wire` (`"0.3"`, exakte Version über `Cargo.lock`). Liegt offline keine 0.3.x im Cache, schlägt die Auflösung fehl; dann die lokal vorhandene Version eintragen.

### Nebenbefund zum Gate-0-Build

Im Archiv passt `bsc/gates/gate0/Cargo.lock` nicht zu `bsc/gates/gate0/Cargo.toml`: Das Lockfile enthält kein einziges `reth-*`-Paket und kein `tokio`, obwohl `Cargo.toml` beides verlangt, und es führt `alloy-rlp 0.3.16`, während `Cargo.toml` `=0.3.13` festlegt. Ein `--locked`-Build aus dem committeten Stand kann so nicht gelingen. Das tatsächlich lokal verwendete Lockfile sollte unverändert committet werden; nicht neu erzeugen.

## 2. Bestand in Zahlen

| Größe | Wert |
|---|---|
| Rust-Zeilen in `gate0/src` | 9.221 |
| Funktionen ohne Tests | 252 (109 verschiedene Namen) |
| `#[test]`-Funktionen | 32 |
| Bibliotheksmodule in `lib.rs` | 5 (`acceptance_guard`, `intent_lane`, `native_bnb_quote`, `p2p_ingress`, `restart_fence`) |
| Einzelprogramme (`main.rs` + `bin/`) | 18 |
| Dateien mit eigener RLP-Kodierung | 12 |
| Dateien mit eigener Signatur-Stelle (`sign_prehash_recoverable`) | 10 (4 als `sign_legacy`, 6 inline in `run_once`/`main`) |
| Dateien mit eigenem `sol!`-ABI-Block | 12 |

## 3. Inventar je Zielmodul

Spalte „Kopien / Varianten": Anzahl der Definitionen / Anzahl unterschiedlicher Funktionskörper (Leerraum und Kommentare ignoriert).

**Modulgrenze (Review-Punkt 3):** `darkbot-core` führt kein I/O aus. Im Core liegen reine Zustände und reine Byte-Konstruktion: Intent-/Nonce-/Recovery-Zustand, Payload-Bytes der Adapter. Tatsächlicher Transport, Verbindungspflege, Secrets und die dauerhafte Startup-Fence liegen im Runner-/Adapter-Bereich, Capture im Recorder. Das Send-Permit wird unmittelbar vor dem tatsächlichen Write konsumiert; ein ACK ist nie ein `confirm`. Diese Trennung ist eine Modulgrenze und führt keine zusätzliche Task-, Prozess- oder Queue-Grenze ein.

### `darkbot-wire::rlp`

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `rlp_bytes` | 12 / 3 | g05_e2e_local:98, g05_ipc:14, g05_local:96, g05_remote_e2e:102, g05_remote_e2e_stability:101, g06_concurrency:34, g06a_48club_floor_probe:17, g06a_self_launch_bundle:95, g06a_target_handoff:108, g07_testnet_birth_buy:160, g07_testnet_buy:89, main:18 | ja — G0.3 Mainnet-TX-Hash, G0.7 ausgeführte Testnet-TXs | **Einheit 1**: eine Implementierung, Puffer-Writer statt `Vec<Vec<u8>>`, kein `unwrap` |
| `rlp_list` | 12 / 4 | g05_e2e_local:141, g05_ipc:42, g05_local:139, g05_remote_e2e:145, g05_remote_e2e_stability:144, g06_concurrency:72, g06a_48club_floor_probe:27, g06a_self_launch_bundle:133, g06a_target_handoff:146, g07_testnet_birth_buy:198, g07_testnet_buy:127, main:48 | ja — G0.3 Mainnet-TX-Hash, G0.7 ausgeführte Testnet-TXs | **Einheit 1**: eine Implementierung, Puffer-Writer statt `Vec<Vec<u8>>`, kein `unwrap` |
| `rlp_u256` | 10 / 2 | g05_e2e_local:131, g05_local:129, g05_remote_e2e:135, g05_remote_e2e_stability:134, g06_concurrency:63, g06a_48club_floor_probe:26, g06a_self_launch_bundle:124, g06a_target_handoff:137, g07_testnet_birth_buy:189, g07_testnet_buy:118 | ja — G0.3 Mainnet-TX-Hash, G0.7 ausgeführte Testnet-TXs | **Einheit 1**: eine Implementierung, Puffer-Writer statt `Vec<Vec<u8>>`, kein `unwrap` |
| `rlp_u64` | 10 / 2 | g05_e2e_local:121, g05_local:119, g05_remote_e2e:125, g05_remote_e2e_stability:124, g06_concurrency:54, g06a_48club_floor_probe:25, g06a_self_launch_bundle:115, g06a_target_handoff:128, g07_testnet_birth_buy:180, g07_testnet_buy:109 | ja — G0.3 Mainnet-TX-Hash, G0.7 ausgeführte Testnet-TXs | **Einheit 1**: eine Implementierung, Puffer-Writer statt `Vec<Vec<u8>>`, kein `unwrap` |
| `rlp_hex` | 2 / 1 | g05_ipc:34, main:40 | ja — G0.3 | entfällt: Hex-Eingabe gehört nicht in den Encoder; `put_uint_be` deckt die Semantik (führende Nullen entfernen) |
| `bytes_u64` | 1 / 1 | g06a_self_launch_bundle:256 | teilweise — nur eigene TXs (G0.6a DRY-1) | **Einheit 1**: strenger Decoder ohne Panic/Kopie (`take_bytes`, `list_payload_exact`, `uint_u64`) |
| `decode_rlp_list_payload` | 1 / 1 | g06a_self_launch_bundle:238 | teilweise — nur eigene TXs (G0.6a DRY-1) | **Einheit 1**: strenger Decoder ohne Panic/Kopie (`take_bytes`, `list_payload_exact`, `uint_u64`) |
| `rlp_item` | 1 / 1 | g06a_self_launch_bundle:218 | teilweise — nur eigene TXs (G0.6a DRY-1) | **Einheit 1**: strenger Decoder ohne Panic/Kopie (`take_bytes`, `list_payload_exact`, `uint_u64`) |

### `darkbot-core::tx::legacy` + `darkbot-core::signer`

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `sign_legacy` | 4 / 4 | g06_concurrency:115, g06a_self_launch_bundle:167, g06a_target_handoff:174, g07_testnet_birth_buy:222 | ja — G0.3, G0.6 (1024 Envelopes), G0.7 Testnet | **Einheit 1**: `Signer::sign_legacy` ist der einzige öffentliche Weg zu signierten Bytes; Chain-ID/Gas als Felder statt Konstanten; Fehler statt `expect` |
| `sign_dummy` | 1 / 1 | g06a_48club_floor_probe:33 | nein — Diagnose-Probe | in neuen Qualifikationsprogrammen `Signer::sign_legacy`; kein eigener Code |

### `darkbot-core::signer`

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `signer_address` | 4 / 2 | g06a_self_launch_bundle:89, g06a_target_handoff:168, g07_testnet_birth_buy:154, g07_testnet_buy:151 | ja — G0.7 | **Einheit 1**: `address_of` / `Signer::address` |
| `recover_sender` | 1 / 1 | g06a_self_launch_bundle:261 | ja — G0.3 Schritt 4, G0.6a DRY-1 | **Einheit 1**: `recover_legacy_sender(signed, expected_chain_id, …)`, prüft Chain und lehnt High-S ab |
| `sender` | 1 / 1 | g05_remote_e2e:351 | ja — G0.7 | **Einheit 1**: `address_of` / `Signer::address` |

### `darkbot-core::venues::flap`

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `buy_calldata` | 3 / 3 | g06a_self_launch_bundle:361, g06a_target_handoff:262, g07_testnet_birth_buy:340 | ja — G0.3 Mainnet, G0.7 Testnet | Einheit 2: eine Funktion `(token, input, min_output)`; Variante mit `TESTNET_MIN_OUTPUT = 0` wird **nicht** übernommen |
| `launch_calldata` | 3 / 3 | g06a_self_launch_bundle:327, g06a_target_handoff:228, g07_testnet_birth_buy:306 | ja — Testnet (Encode); Mainnet-Decode nur G0.6 pending decode | Einheit 2: Produktion braucht **Decode** fremder `newTokenV6`-Calldata; Encode bleibt Werkzeug für Eigen-Launch |
| `predicted_token` | 3 / 2 | g06a_self_launch_bundle:313, g06a_target_handoff:213, g07_testnet_birth_buy:263 | ja — Testnet-Launches (Adresse = Vorhersage), Mainnet read-only | Einheit 2: Portal/Impl als versionierte Venue-Konfiguration, Init-Code-Hash einmal vorberechnen, kein `hex::decode` je Aufruf |
| `make_calldata` | 1 / 1 | g06_concurrency:102 | ja — G0.3 Mainnet, G0.7 Testnet | Einheit 2: eine Funktion `(token, input, min_output)`; Variante mit `TESTNET_MIN_OUTPUT = 0` wird **nicht** übernommen |

### `darkbot-core::economics`

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `n` | 6 / 1 | g03:19, g05_e2e_local:64, g05_local:62, g05_remote_e2e:68, g05_remote_e2e_stability:67, g06_concurrency:30 | ja — G0.3 (DOGE-Modus, 3 Tests) | Einheit 3: übernehmen; Fehler statt `assert` |
| `narrow` | 6 / 3 | g03:25, g05_e2e_local:72, g05_local:70, g05_remote_e2e:76, g05_remote_e2e_stability:75, native_bnb_quote:41 | ja — G0.3 (DOGE-Modus, 3 Tests) | Einheit 3: übernehmen; Fehler statt `assert` |
| `wide` | 6 / 1 | g03:22, g05_e2e_local:68, g05_local:66, g05_remote_e2e:72, g05_remote_e2e_stability:71, native_bnb_quote:37 | ja — G0.3 (DOGE-Modus, 3 Tests) | Einheit 3: übernehmen; Fehler statt `assert` |
| `ceil_div` | 5 / 1 | g03:38, g05_e2e_local:81, g05_local:79, g05_remote_e2e:85, g05_remote_e2e_stability:84 | ja — G0.3 (DOGE-Modus, 3 Tests) | Einheit 3: übernehmen; Fehler statt `assert` |
| `min_output` | 5 / 2 | g03:46, g05_e2e_local:90, g05_local:88, g05_remote_e2e:94, g05_remote_e2e_stability:93 | ja — G0.3 (DOGE-Modus, 3 Tests) | Einheit 3: **g03-Variante** ist maßgeblich (prüft `bps < 10000`); Fehler statt `assert` |
| `mul_div` | 5 / 2 | g03:34, g05_e2e_local:77, g05_local:75, g05_remote_e2e:81, g05_remote_e2e_stability:80 | ja — G0.3 (DOGE-Modus, 3 Tests) | Einheit 3: übernehmen; Fehler statt `assert` |

### `darkbot-core::economics` / `darkbot-core::venues::flap`

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `curve20` | 1 / 1 | native_bnb_quote:61 | ja — G0.6a EVM-Crosscheck PASS (4 Tests) | Einheit 3: übernehmen; Kurvenparameter als versionierte Venue-Konstanten; Fehler statt `assert` |
| `div_wad_up` | 1 / 1 | native_bnb_quote:51 | ja — G0.6a EVM-Crosscheck PASS (4 Tests) | Einheit 3: übernehmen; Kurvenparameter als versionierte Venue-Konstanten; Fehler statt `assert` |
| `estimate_supply` | 1 / 1 | native_bnb_quote:70 | ja — G0.6a EVM-Crosscheck PASS (4 Tests) | Einheit 3: übernehmen; Kurvenparameter als versionierte Venue-Konstanten; Fehler statt `assert` |
| `mul_div_down` | 1 / 1 | native_bnb_quote:46 | ja — G0.6a EVM-Crosscheck PASS (4 Tests) | Einheit 3: übernehmen; Kurvenparameter als versionierte Venue-Konstanten; Fehler statt `assert` |
| `quote_native_buy` | 1 / 1 | native_bnb_quote:88 | ja — G0.6a EVM-Crosscheck PASS (4 Tests) | Einheit 3: übernehmen; Kurvenparameter als versionierte Venue-Konstanten; Fehler statt `assert` |

### `darkbot-core::inclusion` (Intent/Nonce-Ownership, reiner Zustand)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `begin_send` | 2 / 2 | intent_lane:122, restart_fence:73 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `confirm` | 2 / 2 | intent_lane:134, restart_fence:77 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `halt` | 2 / 2 | intent_lane:161, restart_fence:80 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `hash` | 2 / 2 | intent_lane:176/282 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `new` | 2 / 2 | builder_lifecycle_tests:62, intent_lane:59 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `prepare` | 2 / 2 | intent_lane:105, restart_fence:70 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `reserve` | 2 / 2 | intent_lane:74, restart_fence:67 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `token` | 2 / 2 | intent_lane:170/279 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `binding` | 1 / 1 | intent_lane:17 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `identity` | 1 / 1 | intent_lane:71 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `lane` | 1 / 1 | intent_lane:173 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |
| `nonce` | 1 / 1 | intent_lane:20 | ja — 9 + 4 + 5 Tests, G0.6 dry | Einheit 4: Zustandsautomat ohne I/O übernehmen; Zustände `unknown/included/reverted/canonical` an `chain_state` anbinden; ACK ist nie `confirm` |

### `darkbot-core::inclusion` (Payload-Bytes, rein) + `darkbot-runner` (HTTP-Rahmen)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `http_request` | 4 / 3 | g05_remote_e2e:206, g05_remote_e2e_stability:174, g05_remote_transport:20, g06a_target_handoff:275 | ja — G0.5 PASS (48Club, BlockRazor) | Einheit 5: Payload je Adapter (`eth_sendBundle`-Optionen) als reine Byte-Konstruktion im Core, vor T0 vorbereitbar; HTTP-Rahmen und Write im Adapter |
| `https_request` | 1 / 1 | g07_testnet_birth_buy:439 | ja — G0.5 PASS (48Club, BlockRazor) | Einheit 5: Payload je Adapter (`eth_sendBundle`-Optionen) als reine Byte-Konstruktion im Core, vor T0 vorbereitbar; HTTP-Rahmen und Write im Adapter |
| `request` | 1 / 1 | g06a_presigned_handoff_transport:76 | ja — G0.5 PASS (48Club, BlockRazor) | Einheit 5: Payload je Adapter (`eth_sendBundle`-Optionen) als reine Byte-Konstruktion im Core, vor T0 vorbereitbar; HTTP-Rahmen und Write im Adapter |

### `darkbot-runner` (Startup-Fence, Datei-I/O) + `darkbot-core::inclusion` (Fence-Zustand)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `arm` | 2 / 2 | restart_fence:30/103 | ja — 4 Tests | Einheit 4: Entscheidung/Zustand im Core, Dateisynchronisation im Runner beim Start; Fence ist Fail-closed-Quarantäne, keine automatische kanonische Recovery |
| `for_transport` | 1 / 1 | restart_fence:64 | ja — 4 Tests | Einheit 4: Entscheidung/Zustand im Core, Dateisynchronisation im Runner beim Start; Fence ist Fail-closed-Quarantäne, keine automatische kanonische Recovery |
| `from` | 1 / 1 | restart_fence:18 | ja — 4 Tests | Einheit 4: Entscheidung/Zustand im Core, Dateisynchronisation im Runner beim Start; Fence ist Fail-closed-Quarantäne, keine automatische kanonische Recovery |
| `root` | 1 / 1 | restart_fence:90 | ja — 4 Tests | Einheit 4: Entscheidung/Zustand im Core, Dateisynchronisation im Runner beim Start; Fence ist Fail-closed-Quarantäne, keine automatische kanonische Recovery |

### `darkbot-runner` (Inclusion-Adapter, I/O)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `find_header_end` | 5 / 1 | g05_remote_e2e:222, g05_remote_e2e_stability:190, g05_remote_transport:36, g06a_presigned_handoff_transport:85, g06a_target_handoff:284 | ja — G0.5 | Einheit 5: ein HTTP-Antwortleser; liegt nach `T_send`, nicht im Hotpath |
| `read_http` | 5 / 5 | g05_remote_e2e:267, g05_remote_e2e_stability:194, g05_remote_transport:40, g06a_presigned_handoff_transport:89, g06a_target_handoff:310 | ja — G0.5 | Einheit 5: ein HTTP-Antwortleser; liegt nach `T_send`, nicht im Hotpath |
| `body_of` | 4 / 1 | g05_remote_e2e:314, g05_remote_e2e_stability:234, g05_remote_transport:80, g06a_target_handoff:338 | ja — G0.5 | Einheit 5: ein HTTP-Antwortleser; liegt nach `T_send`, nicht im Hotpath |
| `connect_tls` | 2 / 2 | g06a_presigned_handoff_transport:48, g06a_target_handoff:343 | ja — G0.5 / G0.7 | Einheit 5: eine vorgewärmte TLS-Verbindung je Adapter; Reconnect-Politik explizit |
| `decode_chunked_body` | 2 / 2 | g05_remote_e2e:226, g06a_target_handoff:288 | ja — G0.5 | Einheit 5: ein HTTP-Antwortleser; liegt nach `T_send`, nicht im Hotpath |
| `connect` | 1 / 1 | g06a_48club_floor_probe:49 | ja — G0.5 / G0.7 | Einheit 5: eine vorgewärmte TLS-Verbindung je Adapter; Reconnect-Politik explizit |
| `connect_testnet_https` | 1 / 1 | g07_testnet_birth_buy:414 | ja — G0.5 / G0.7 | Einheit 5: eine vorgewärmte TLS-Verbindung je Adapter; Reconnect-Politik explizit |
| `guarded_transport_write` | 1 / 1 | g05_remote_e2e:357 | ja — 5 Tests (`builder_lifecycle_tests`) | Einheit 5: einziger Schreibpfad aller Adapter; konsumiert das Core-Permit unmittelbar vor dem tatsächlichen Write |
| `http` | 1 / 1 | g06a_48club_floor_probe:59 | ja — G0.5 / G0.7 | Einheit 5: eine vorgewärmte TLS-Verbindung je Adapter; Reconnect-Politik explizit |
| `https_send_prepared` | 1 / 1 | g07_testnet_birth_buy:452 | ja — G0.5 / G0.7 | Einheit 5: eine vorgewärmte TLS-Verbindung je Adapter; Reconnect-Politik explizit |
| `try_https_connect` | 1 / 1 | g07_testnet_birth_buy:355 | ja — G0.5 / G0.7 | Einheit 5: eine vorgewärmte TLS-Verbindung je Adapter; Reconnect-Politik explizit |

### `darkbot-runner` (Tests)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `context` | 1 / 1 | builder_lifecycle_tests:5 | n/a | Test-Double, bleibt in Tests |
| `flush` | 1 / 1 | builder_lifecycle_tests:98 | n/a | Test-Double, bleibt in Tests |
| `read` | 1 / 1 | builder_lifecycle_tests:78 | n/a | Test-Double, bleibt in Tests |
| `write` | 1 / 1 | builder_lifecycle_tests:83 | n/a | Test-Double, bleibt in Tests |

### `darkbot-runner`::live (Sendefreigabe)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `inspect_v2` | 1 / 1 | acceptance_guard:67 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `norm_addr` | 1 / 1 | acceptance_guard:35 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `opt_string` | 1 / 1 | acceptance_guard:59 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `req_bool` | 1 / 1 | acceptance_guard:39 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `req_u128_string` | 1 / 1 | acceptance_guard:51 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `req_u64` | 1 / 1 | acceptance_guard:45 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `sha256_hex` | 1 / 1 | acceptance_guard:63 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |
| `verify_live_authorization` | 1 / 1 | acceptance_guard:100 | ja — 2 Tests, Guard `UNARMED` | übernehmen; Fehler-Typ statt `String` |

### `darkbot-runner` (typisierte Konfiguration / Secret-Pfad)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `host` | 3 / 3 | g05_remote_e2e:185, g06a_presigned_handoff_transport:31, g06a_target_handoff:93 | ja — G0.5 | Einheit 6: Endpunkte in typisierte Konfiguration, nicht im Code |
| `label` | 3 / 3 | g05_remote_e2e:197, g06a_presigned_handoff_transport:40, g06a_target_handoff:100 | ja — G0.5 | Einheit 6: Endpunkte in typisierte Konfiguration, nicht im Code |
| `from_args` | 2 / 2 | g06a_presigned_handoff_transport:23, g06a_target_handoff:85 | ja — G0.5 | Einheit 6: Endpunkte in typisierte Konfiguration, nicht im Code |
| `env_u128` | 1 / 1 | g06a_self_launch_bundle:75 | n/a | neu zu bauen: typisierte Konfiguration; Secret nur über Environment/Secret-Store, nie geloggt |
| `env_u64` | 1 / 1 | g06a_self_launch_bundle:69 | n/a | neu zu bauen: typisierte Konfiguration; Secret nur über Environment/Secret-Store, nie geloggt |
| `key_from_env` | 1 / 1 | g06a_self_launch_bundle:81 | n/a | neu zu bauen: typisierte Konfiguration; Secret nur über Environment/Secret-Store, nie geloggt |
| `port` | 1 / 1 | g05_remote_e2e:193 | ja — G0.5 | Einheit 6: Endpunkte in typisierte Konfiguration, nicht im Code |
| `req_env` | 1 / 1 | g06a_self_launch_bundle:65 | n/a | neu zu bauen: typisierte Konfiguration; Secret nur über Environment/Secret-Store, nie geloggt |

### `darkbot-runner` (Qualifikations-Werkzeug, nur Eigen-Launch)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `find_vanity_salt` | 1 / 1 | g07_testnet_birth_buy:281 | ja — Testnet | nicht im Produktions-Hotpath; nutzt danach `venues::flap::predicted_token` |

### `darkbot-capture` (Recorder: kanonischer Abgleich, I/O abseits des Hotpaths)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `hex_u256` | 2 / 1 | g07_testnet_birth_buy:131, g07_testnet_buy:81 | ja — G0.7 (Receipts, Transfer = balanceOf) | Minimal-Capture: Recorder-/Reconcile-Pfad; `successful_competing_buys_between` auf Event-Basis (`TokenBought`) statt nur Top-Level-Calls |
| `hex_u64` | 2 / 1 | g07_testnet_birth_buy:123, g07_testnet_buy:73 | ja — G0.7 (Receipts, Transfer = balanceOf) | Minimal-Capture: Recorder-/Reconcile-Pfad; `successful_competing_buys_between` auf Event-Basis (`TokenBought`) statt nur Top-Level-Calls |
| `rpc` | 2 / 2 | g07_testnet_birth_buy:94, g07_testnet_buy:37 | ja — G0.7 (Receipts, Transfer = balanceOf) | Minimal-Capture: Recorder-/Reconcile-Pfad; `successful_competing_buys_between` auf Event-Basis (`TokenBought`) statt nur Top-Level-Calls |
| `balance_of` | 1 / 1 | g07_testnet_birth_buy:625 | ja — G0.7 (Receipts, Transfer = balanceOf) | Minimal-Capture: Recorder-/Reconcile-Pfad; `successful_competing_buys_between` auf Event-Basis (`TokenBought`) statt nur Top-Level-Calls |
| `receipt` | 1 / 1 | g07_testnet_birth_buy:613 | ja — G0.7 (Receipts, Transfer = balanceOf) | Minimal-Capture: Recorder-/Reconcile-Pfad; `successful_competing_buys_between` auf Event-Basis (`TokenBought`) statt nur Top-Level-Calls |
| `successful_competing_buys_between` | 1 / 1 | g07_testnet_birth_buy:637 | ja — G0.7 (Receipts, Transfer = balanceOf) | Minimal-Capture: Recorder-/Reconcile-Pfad; `successful_competing_buys_between` auf Event-Basis (`TokenBought`) statt nur Top-Level-Calls |

### `darkbot-capture` (Latenz-Records, Offline-Auswertung)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `stats` | 8 / 5 | g05_e2e_local:388, g05_ipc:76, g05_local:372, g05_remote_e2e:665, g05_remote_e2e_stability:503, g05_remote_transport:85, g06a_presigned_handoff_transport:162, g06a_target_handoff:478 | n/a | eine Perzentil-Auswertung; 5 Varianten unterscheiden sich nur im Ausgabeformat |
| `once` | 1 / 1 | g05_ipc:98 | n/a | eine Perzentil-Auswertung; 5 Varianten unterscheiden sich nur im Ausgabeformat |
| `pct` | 1 / 1 | g06_concurrency:163 | n/a | eine Perzentil-Auswertung; 5 Varianten unterscheiden sich nur im Ausgabeformat |

### Gate-0-Referenz (Reth-Sensor); kein Produktions-Ingress

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `decode` | 2 / 2 | p2p_ingress:76/97 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `encode` | 2 / 2 | p2p_ingress:70/90 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `as_str` | 1 / 1 | p2p_ingress:291 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `bsc_testnet_bootnodes` | 1 / 1 | p2p_ingress:274 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `bsc_testnet_chain_spec` | 1 / 1 | p2p_ingress:252 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `bsc_testnet_hardforks` | 1 / 1 | p2p_ingress:205 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `handshake` | 1 / 1 | p2p_ingress:122 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `into_rlpx` | 1 / 1 | p2p_ingress:111 | teilweise — nur Chapel, nur ein erwarteter Hash | bleibt eingefrorene Referenz/Qualifikation; Produktions-Ingress ist der gepinnte bsc-geth-Hook über `darkbot-fastlane` (C1) |
| `latest_p2p_head` | 1 / 1 | g07_testnet_birth_buy:139 | ja — Testnet | bleibt beim Referenz-Sensor |

### entfällt (Harness-Steuerung)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `main` | 17 / 17 | g03:50, g05_e2e_local:411, g05_ipc:128, g05_local:395, g05_remote_e2e:691, g05_remote_e2e_stability:531, g05_remote_transport:111, g06_concurrency:169, g06_flap_pending_decode:38, g06a_48club_floor_probe:71, g06a_native_bnb_quote:10, g06a_presigned_handoff_transport:188, g06a_self_launch_bundle:374, g06a_target_handoff:501, g07_testnet_birth_buy:698, g07_testnet_buy:159, main:67 | n/a | Gate-0-Programme bleiben eingefrorene Evidenz |
| `run_once` | 6 / 6 | g05_e2e_local:196, g05_local:193, g05_remote_e2e:383, g05_remote_e2e_stability:269, g06a_presigned_handoff_transport:135, g06a_target_handoff:373 | n/a | Gate-0-Programme bleiben eingefrorene Evidenz |
| `fields` | 1 / 1 | g06_concurrency:425 | n/a | Gate-0-Programme bleiben eingefrorene Evidenz |
| `fixture` | 1 / 1 | g06_concurrency:437 | n/a | Gate-0-Programme bleiben eingefrorene Evidenz |
| `run` | 1 / 1 | g06a_48club_floor_probe:62 | n/a | Gate-0-Programme bleiben eingefrorene Evidenz |
| `run_probe` | 1 / 1 | g05_remote_e2e:375 | n/a | Gate-0-Programme bleiben eingefrorene Evidenz |

### entfällt (synthetische Test-Ableitung, kein Flap-CREATE2)

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `derive_token` | 1 / 1 | g06_concurrency:94 | n/a | nur Test-Fixture für G0.6-Nebenläufigkeit; in Tests von `inclusion` belassen |

### entfällt

| Funktion | Kopien / Varianten | Fundstellen (Datei:Zeile) | Semantik bewiesen? | Änderung |
|---|---|---|---|---|
| `wait_rpc_id` | 1 / 1 | g07_testnet_birth_buy:599 | n/a | WSS ist deaktiviert (Ledger 2026-10-03); wird nicht migriert |
| `ws_connect` | 1 / 1 | g07_testnet_birth_buy:457 | n/a | WSS ist deaktiviert (Ledger 2026-10-03); wird nicht migriert |
| `ws_read_message` | 1 / 1 | g07_testnet_birth_buy:540 | n/a | WSS ist deaktiviert (Ledger 2026-10-03); wird nicht migriert |
| `ws_send_frame` | 1 / 1 | g07_testnet_birth_buy:509 | n/a | WSS ist deaktiviert (Ledger 2026-10-03); wird nicht migriert |
| `ws_send_text` | 1 / 1 | g07_testnet_birth_buy:536 | n/a | WSS ist deaktiviert (Ledger 2026-10-03); wird nicht migriert |


Zusätzlich zu den Funktionen:

| Bestand | Kopien | Zielmodul | Änderung |
|---|---|---|---|
| `sol!`-Block (`LaunchParams`, `newTokenV6`, `SwapParams`, `swapExactInput`) | 12 Dateien | `darkbot-core::venues::flap` | Einheit 2: eine ABI-Definition, an die eingefrorene Portal-Version gebunden |
| Inline-Signatur in `run_once`/`main` | 6 Dateien | `darkbot-core::signer` | neue Programme nutzen `Signer::sign_legacy` |
| `TransportKind` + Endpunkt-Konstanten (`g05_remote_e2e.rs:172–184`) | 3 Dateien | Adapter + Konfiguration | Einheit 5/6: Endpunkte nach §6 in typisierte Konfiguration |
| `P2pSignal`, `P2pSensor` (`p2p_ingress.rs:300–325`) | 1 | Gate-0-Referenz | Produktions-Event ist `RawTxSeen` aus dem Minimalvertrag |

## 4. Vorhandene Tests und ihr Ziel

| Datei | Tests | Ziel | Stand |
|---|---|---|---|
| `intent_lane.rs` | 9 | `darkbot-core::inclusion` | Einheit 4, unverändert übernehmen |
| `builder_lifecycle_tests.rs` | 5 | Adapter-Schreibpfad | Einheit 5 |
| `restart_fence.rs` | 4 | Fence-Zustand / Startup-Fence | Einheit 4 |
| `g06_concurrency.rs` | 5 | `signer` (1), `inclusion` (4) | 1 Test in Einheit 1 portiert, 4 in Einheit 4. Der künstliche 25-ms-Head-of-Line-Test ist kein Latenzbefund |
| `native_bnb_quote.rs` | 4 | `darkbot-core::economics` | Einheit 3 |
| `g03.rs` | 3 | `darkbot-core::economics` | Einheit 3 |
| `acceptance_guard.rs` | 2 | `darkbot-runner::live` | mit dem Guard |
| `main.rs` (G0.3 Schritt 4, als Programm) | 1 Prüfung | `tx::legacy`, `signer` | in Einheit 1 als 3 Tests portiert (Signing-Hash, Roh-Bytes, Sender) |

## 5. Abweichungen zwischen Kopien

Nur zwei Abweichungen ändern die Semantik. Alle anderen Varianten unterscheiden sich in Formatierung, Allokation oder Parametrisierung.

1. **`min_output`** — `g03.rs:46` prüft `bps < 10000` (Test `reject_unbounded_slippage`). Die vier Kopien in `g05_local`, `g05_e2e_local`, `g05_remote_e2e`, `g05_remote_e2e_stability` haben die Prüfung nicht; dort ist `10000 - bps` für `bps > 10000` ein Unterlauf. Maßgeblich für Produktion ist die g03-Variante.
2. **`buy_calldata`** — `g07_testnet_birth_buy.rs:340` setzt `minOutputAmount = TESTNET_MIN_OUTPUT = 0` (Zeile 92, als „testnet latency only" markiert). Diese Variante wird nicht übernommen; Produktion verlangt immer einen berechneten `min_output > 0`.

Ohne semantische Wirkung, aber festgehalten:

- `sign_legacy` in `g06_concurrency.rs:115` hat Gaspreis 310.000.000, Gaslimit 1.500.000 und Chain-ID 56 fest im Code. In Produktion sind das Felder von `LegacyTx`.
- `mul_div` in `g03.rs:34` prüft den Divisor ausdrücklich; die übrigen Kopien verlassen sich auf die Division.
- `signer_address` in `g07_testnet_buy.rs:151` prüft zusätzlich das SEC1-Tag `0x04`.
- `rlp_list` nimmt in 8 Dateien `Vec<Vec<u8>>` per Wert, in 4 Dateien `&[Vec<u8>]`.

## 6. Nicht übernommen

| Bestand | Grund |
|---|---|
| WSS-Helfer (`ws_connect`, `ws_send_frame`, `ws_send_text`, `ws_read_message`, `wait_rpc_id`) | WSS ist deaktiviert (Ledger 2026-10-03) |
| `derive_token` (`g06_concurrency.rs:94`) | synthetische Test-Ableitung, kein Flap-CREATE2 |
| Absichtliche Beschädigung `wire[0] = 0x00` (`g05_remote_e2e.rs:559`) | Schutz des G0.5-Transport-Benchmarks; bleibt im Harness |
| `run_once`, `run_probe`, `main`, `fixture` | Harness-Steuerung |
| `rlp_hex` | Hex-Eingabe gehört nicht in den Encoder |
| Testnet-Schlüssel und -Wallets | werden weder portiert noch gespeichert |

## 7. Entscheidungen

**E1 — Bau-Freigabe gegen LIVE-Sperre: Formulierung zur Freigabe.**
Betroffen: `docs/BSC_NATIVE_SINGLE_RUNTIME_CONTRACT.md:3` und `:11`, `docs/BSC_DUAL_VENUE_ROADMAP.md:90` und `:187`, dazu die STOP-Regel des Testplans. Vorgeschlagener Wortlaut für alle Stellen:

> C0/Konsolidierung und Messaufbau freigegeben; Produktions-LIVE weiterhin gesperrt bis Qualifikation. Unbekannte Gate-0-Ergebnisse bleiben unbekannt; der Bau ist kein Gate-PASS.

Die Roadmap-Tabelle führt G0.3 bis G0.11 noch als „BLOCKED", während das Ledger Ergebnisse für G0.3 bis G0.7 enthält. Diese Zeilen gegen das Ledger abgleichen. Diese Lieferung ändert keine Repo-Dokumente; die Freigabe liegt beim Auftraggeber.

**E2 — Produktions-Ingress: entschieden durch Review.**
Produktionsbaseline ist der gepinnte bsc-geth mit nativem Hook und mmap-SPSC (`darkbot-fastlane`), wie Runtime Contract §2/§5 und Roadmap C1 festlegen. Der Reth-Sensor (`p2p_ingress.rs`) bleibt Gate-0-/Referenz-Evidenz und wird nicht als zweiter Produktionsstack gebaut. Direktes Rust-devp2p nur, wenn eine Messung zeigt, dass geth-Ingress Vorsprung kostet (§15 Level 4). Die Leistung dieser Baseline ist noch zu messen.

**E3 — Ablageort RLP: entschieden durch Review.** Bleibt in `darkbot-wire`.

**E4 — Transaktionstypen: korrigiert.**
Die Aussage aus Revision 1, die Launch-Typen seien im Repo nicht belegt, war falsch. Belegt ist: Die fünf identifizierten `newTokenV6`-Launches in den G0.4-Mitschnitten (Selektor `0x8cb5772c`) sind Typ 0. Im Coverage-V2-Mitschnitt sind von 46 Portal-Pending-TXs 43 Typ 0 und 3 Typ 2. Das ist eine Stichprobe, keine vollständige Abdeckung.
Folge: Der Ingress ist envelope-agnostisch (`RawTxSeen` im Minimalvertrag: originale signierte Bytes, `envelope_type`, normalisierte gemeinsame Felder vom Hook). `LegacyTx` bleibt ausschließlich der eigene BUY-Encoder. Nicht unterstützte Typen werden gezählt, nicht still verworfen.

**E5 — `gas_price` als `u64` oder `U256`: offen, klein.**
Review 1: `u64` ist als enger BSC-Scope dokumentiert und kein zwingender Umbau. Review 2: Tendenz zu `U256` im Wire-Modell. Geliefert ist `u64` mit ausdrücklichem Scope. Die Umstellung beträfe ein Feld, zwei Encoder-Zeilen und den Decoder.

## 8. Gate 0 bleibt eingefroren

Die historischen Gate-0-Programme und ihre Rohbelege werden nicht umgebaut und nicht gelöscht. Sie sind Evidenz und Referenz, nicht Produktions-Legacy: Sie gelangen nicht ins Produktionsprogramm.

- `bsc/native` ist die einzige künftige Implementierung.
- Neue Qualifikationsprogramme verwenden `bsc/native` und vergleichen gegen die eingefrorenen Golden-Vektoren (rohe Bytes, Hashes, kurze Signaturskalare, gültige und ungültige Signaturen, Empfänger-Bindung).
- Wird ein Gate-0-Programm tatsächlich weiterverwendet, wird nur dieses umgestellt, mit Paritätsnachweis vor dem Entfernen seiner Kopien.

Ersetzungen für solche Einzelfälle:

| Gate-0 | Ersatz |
|---|---|
| `rlp_bytes(b)` | `darkbot_wire::rlp::encode_bytes(b)` |
| `rlp_u64(v)` | `darkbot_wire::rlp::encode_u64(v)` |
| `rlp_u256(v)` | `darkbot_wire::rlp::encode_uint_be(&v.to_be_bytes::<32>())` |
| `rlp_list(vec![…])`, `rlp_list(&[…])` | `darkbot_wire::rlp::encode_list(&[…])` |
| `sign_legacy(…)` und Inline-Signatur | `Signer::sign_legacy(&LegacyTx { … }, &mut scratch, &mut raw)` |
| `signer_address(&key)`, `sender(ctx)` | `signer.address()` |
| `recover_sender(&tx)` | `recover_legacy_sender(&decode_signed(&raw)?, chain_id, &mut scratch)` |

## 9. Reihenfolge

| Schritt | Inhalt | Zielmodul | Stand |
|---|---|---|---|
| Einheit 1 | RLP, Legacy-TX, Signer, Recovery | `darkbot-wire::rlp`, `core::tx::legacy`, `core::signer` | Revision 2 geliefert; Lauf, Review, Import offen |
| Minimalvertrag | Event, Clock, Attempt, 15-s-Capture | `C0_EVENT_CLOCK_CAPTURE_CONTRACT.md` | Vorschlag geliefert; einfrieren vor dem ersten Verbraucher |
| Einheit 2 | Flap-ABI, Calldata, CREATE2-Adresse, Launch-Decode | `core::venues::flap` | offen |
| Einheit 3 | Quote, `min_output`, native-BNB-Kurve | `core::economics` | offen |
| Einheit 4 | Intent-/Nonce-Zustand, Fence-Zustand | `core::inclusion` | offen |
| Einheit 5 | Inclusion-Adapter (48Club, BlockRazor, lokal), Payload-Bytes | `core::inclusion` + Runner-Adapter | offen |
| Einheit 6 | Sendefreigabe, typisierte Konfiguration, Secret-Pfad | `darkbot-runner` | offen |
| Minimal-Capture | Records aus dem Minimalvertrag, Recorder | `darkbot-capture` | **vor dem nächsten integrierten echten BUY** |
| C1 | bsc-geth-Hook, mmap-SPSC | `darkbot-fastlane` | offen |
| C2 | Runtime-State (Pending, Canonical, Reorg, Recovery) | `core::chain_state` | offen |

Vorgaben aus dem Review für die Einheiten 2 und 3:

- DOGE-/Converter-Mainnet-Fixture und native-BNB-Testnet-Kurve getrennt führen.
- Portal-, Implementation-, Init-Code-, Quote-, Fee-, Tax- und Extension-Herkunft versioniert festhalten.
- Explizit testen: bps-Grenze, positiver gerundeter `min_output`, Null-Divisor, Überlauf, Rundung, Invalidierung bei veraltetem Zustand.
- Vorsignierte Payloads werden ungültig bei Änderung von Nonce, Gas, Launch-Replacement oder relevantem Zustand. Fehlende Daten führen zu Skip, nie zu einem RPC im Hotpath.
- Konstante ABI- und TX-Felder vorab bereitstellen. Wegen variabler RLP-Längen werden signierte Bytes nie an festen Positionen gepatcht, sondern neu kodiert und neu signiert.

Parallel und ohne den Bau zu blockieren: Builder-Placement, Producer-Messung `T0 → T_buy`, Mainnet-Capture. Grüne Unit-Tests sind kein Gate-PASS und keine Freigabe für einen Lauf mit Wert.
