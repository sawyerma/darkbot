declare module "buffer-layout";
