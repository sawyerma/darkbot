declare module 'buffer-layout';
